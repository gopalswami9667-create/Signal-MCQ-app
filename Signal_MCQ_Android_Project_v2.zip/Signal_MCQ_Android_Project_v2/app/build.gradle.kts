plugins { id("com.android.application") }

android { namespace = "com.signal.mcqtest"; compileSdk = 35
    defaultConfig { applicationId = "com.signal.mcqtest"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "2.0" }
}
